# Changelog lcddisplaydesigner

### v1.00 (Build 20210215)
* NEW: Published on Github
