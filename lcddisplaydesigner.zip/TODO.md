# ToDo lcddisplaydesigner

### LCD Display Character Navigation
Use arrow keys to navigate through the LCD Display Character TextFields.
#### Status
Not started.

### Custom Character Placeholder
Define up-to 8 custom character placeholder.
Solution thoughts:
* Use 8 colors for each of the custom characters set for a character textfield.
#### Status
Not started.
